<?php namespace models\user;

    class User{
        private $id;
        private $name;
        private $pass;
        public $email;

        public function __construct(
            ?int $id = NULL,
            ?string $name = NULL,
            ?string $pass = NULL,
            ?string $email = NULL
        )
        {
            $this->id = NULL;
            $this->name = $name;
            $this->pass = $pass;
            $this->email = $email;
        }

        // function getId($email){
        //     $query = "SELECT id FROM users WHERE email = :email";
        //     $stmt = \src\database\Connect::getInstance()->prepare($query);
        //     $stmt->bindParam(':email', $email);
        //     $stmt->execute();
            
        //     $user = json_encode($stmt->fetchAll());
        //     echo "<pre>";
        //     var_dump($user);
        //     echo "</pre>";
            // var_dump($stmt->email);
        // }

        // function findUser($email){
        //     $id = \models\user\User::getId($email);

        //     $query = "SELECT * FROM users WHERE id = $id;";
        //     $stmt = \src\database\Connect::getInstance()->prepare($query);
        //     $stmt->execute();
        //     return $stmt->fetch();
        // }

        function getData($target, $selector, $value){ 
            $query = "SELECT $target FROM users WHERE $selector = '$value'";
            $stmt = \src\database\Connect::getInstance()->query($query);
            $data = json_encode($stmt->fetchAll());
            return $data;

            /*
                returns a object or boolean

                target => what you want to pick
                selector => what you wll use to filter it(id or email)
                value => the value of selector, like sampleEmail@email.com
            */
        }

        function insert(){
            $query = 'INSERT INTO users VALUES (NULL,:name,:pass,:email)';
            $stmt = \src\database\Connect::getinstance()->prepare($query);

            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":pass", $this->pass);
            $stmt->bindParam(":email", $this->email);

            $stmt->execute();
        }

        function update($id, $column, $newValue){
            $query = "UPDATE users SET $column = :newValue WHERE id = :id";
            $stmt = \src\database\Connect::getInstance()->prepare($query);

            $stmt->bindParam(":id", $id);
            $stmt->bindParam(":newValue", $newValue);
            $stmt->execute();
        }

        function updateEmail($email, $newEmail){
            $id = \models\user\User::getId($email);

            $query = 'UPDATE users SET email = :newEmail WHERE id = $id';
            $stmt = \src\database\Connect::getInstance()->prepare($query);
            $stmt->bindParam(":newEmail", $newEmail);
            $stmt->execute();
        }

        function delete($email){
            $id = \models\user\User::getId($email);

            $query = "DELETE FROM users WHERE id = $id";
            $stmt = \src\database\Connect::getInstance()->prepare($query);
            $stmt->execute();

        }
    }