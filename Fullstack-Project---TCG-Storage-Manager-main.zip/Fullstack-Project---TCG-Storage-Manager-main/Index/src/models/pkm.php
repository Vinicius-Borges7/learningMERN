<?php
    class pkmCard{
        private $id;
        private $name;
        private $cardType;
        private $pokeType;
        private $extras;
        private $quality;
        private $rarity;
        private $owner;

        public function __construct(
            ?int $id = NULL,
            ?string $name = NULL,
            ?string $cardType = NULL,
            ?string $pokeType = NULL,
            ?string $extras = NULL,
            ?string $quality = NULL,
            ?string $rarity = NULL,
            ?int $owner = null
        )
        {
            $this->id = NULL;
            $this->name = $name;
            $this->cardType = $cardType;
            $this->pokeType = $pokeType;
            $this->extras = $extras;
            $this->quality = $quality;
            $this->rarity = $rarity;
            $this->owner = $owner;
        }

        function findCard($id){
            $query = "SELECT * FROM itemMagic WHERE id = $id;";
            $stmt = \src\database\Connect::getInstance()->prepare($query);
            $stmt->execute();
            return $stmt->fetch();
        }

        function insert(){
            $query = 'INSERT INTO itemMagic VALUES (NULL,:name,:cardType,:pokeType,:extras,:quality,:rarity,:owner)';
            $stmt = \src\database\Connect::getinstance()->prepare($query);

            $stmt->bindParam(":name", $this->name);
            $stmt->bindParam(":cardType", $this->cardType);
            $stmt->bindParam(":pokeType", $this->pokeType);
            $stmt->bindParam(":extras", $this->extras);
            $stmt->bindParam(":quality", $this->quality);
            $stmt->bindParam(":rarity", $this->rarity);
            $stmt->bindParam(":owner", $this->owner);
            
            $stmt->execute();
        }

        function update($id, $column, $newValue){
            $query = "UPDATE itemMagic SET $column = :newValue WHERE id = :id";
            $stmt = \src\database\Connect::getInstance()->prepare($query);
            $stmt->bindParam(":id", $id);
            $stmt->bindParam(":newValue", $newValue);
            $stmt->execute();
        }

        function delete($id){
            $query = "DELETE FROM itemMagic WHERE id = $id";
            $stmt = \src\database\Connect::getInstance()->prepare($query);
            $stmt->execute();

        }
    }