<?php
    require '../database/connect.php';
    require '../models/user.php';

////// Functions /////

function verifyUserExistence($User){
    if($User->getData('id', 'email', $_POST['email']) === "[]"){
        return false;
    }
    return true;
}

function registrate($User){
    if(verifyUserExistence($User)){
        return false;
    }
    $User->insert();
    return true;
}

/////////////////////

$NewUser = new \models\user\User(null, $_POST['name'], $_POST['pass'], $_POST['email']);
if(registrate($NewUser)){
    session_start();
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['email'] = $_POST['pass'];
    $_SESSION['pass'] = $_POST['email']; 

    echo json_encode(true);
} else {
    echo json_encode(false);
}