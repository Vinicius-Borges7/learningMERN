<?php
    session_start();
    require '../database/connect.php';
    require '../models/user.php';

////// Functions ///////////////////////////////////////

function getId($user){
    $id = $user->getData('id', 'email', $_POST['email']);
    // echo strCleanner('id', json_encode($id));
    if($id == "[]" || null){
        return false;
    }

    return strCleanner('id', json_encode($id));
}

function getName($user, $id){
    $name = $user->getData('name', 'id', $id);

    if($name == "[]" || null){
        return false;
    }

    return strCleanner('name', json_encode($name));
}

function getEmail($user, $id){
    $email = $user->getData('email', 'id', $id);

    if($email == "[]" || null){
        return false;
    }

    return strCleanner('email', json_encode($email));
}

function getPass($user, $id){
    $pass = $user->getData('pass', 'id', $id);

    if($pass == "[]" || null){
        return false;
    }

    return strCleanner('password', json_encode($pass));
}

///////////////////////////////////////////////////////

function compareData($email, $password){
    if($email != json_encode($_POST['email'])){
        return false;
    }

    if($password != json_encode($_POST['pass'])){
        return false;
    } 

    return true;
}

///////////////////////////////////////////////////////

function strCleanner($target, $string){
    if($target == 'id'){
        $int = substr($string, 12);
        $int = substr($int, 0, -5);
        return $int;
    }

    if($target == 'name'){
        $string = substr($string, 14);
        $string = substr($string, 0, -5);
        return json_encode($string);
    }
    
    if($target == 'email'){
        $string = substr($string, 15);
        $string = substr($string, 0, -5);
        return json_encode($string);
    }

    if($target == 'password'){
        $string = substr($string, 14);
        $string = substr($string, 0, -5);
        return json_encode($string);
    }
}

///////////////////////////////////////////////////////

function login(){
    $user = new \models\user\User(null,null,null,null);
    $id = getId($user);
    $name = getName($user, $id);
    $email = getEmail($user, $id);
    $pass = getPass($user, $id);

    if(compareData($email, $pass)){
        start($name, $email, $pass);
        return true;
    }
    session_abort();
    return false;
}

///////////////////////////////////////////////////////

function start($name, $email, $pass){
    $_SESSION['name'] = $name;
    $_SESSION['email'] = $email;
    $_SESSION['pass'] = $pass;
}

///////////////////////////////////////////////////////

if(login()){
    echo json_encode(true);
} else {
    echo json_encode(false);
}