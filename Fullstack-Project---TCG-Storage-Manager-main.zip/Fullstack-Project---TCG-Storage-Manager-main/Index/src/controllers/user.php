<?php
    require '../database/connect.php';
    require '../models/user.php';

////// functions //////

function updateFields(){
    $user = new \models\user\User(null,null,null,null);
    $str = "";

    if($_POST['email'] != ""){
        updateEmail($user);
        $str = $str . "email,";
    }

    if($_POST['pass'] != ""){
        updatePassword($user);
        $str = $str . "pass,";
    }

    if($_POST['name'] != ""){
        updateName($user);
        $str = $str . "name,";
    }
    return $str;
}

////////////////////////////////

function updateEmail(){
    if(!getEmail($user, getId($user))){
        $user->updateEmail($_SESSION['email'], $_POST['email']);
        return "email";
    }
    return false;    
}

function updatePassword($user){
    $user->update(getId($user), 'pass', $_POST['pass']);
    return "password";
}

function updateName($user){
    $user->update(getId($user), 'name', $_POST['name']);
    return "name";
}

// getters /////////////////////////////////////////////

function getEmail($user, $id){
    $email = $user->getData('email', 'id', $id);

    if($email == "[]" || null){
        return false;
    }

    return strCleanner('email', json_encode($email));
}

function getPass($user, $id){
    $pass = $user->getData('pass', 'id', $id);

    if($pass == "[]" || null){
        return false;
    }

    return strCleanner('password', json_encode($pass));
}

function getName($user, $id){
    $name = $user->getData('name', 'id', $id);

    if($name == "[]" || null){
        return false;
    }

    return strCleanner('name', json_encode($name));
}

function getId($user){
    $id = $user->getData('id', 'email', $_POST['email']);
    if($id == "[]" || null){
        return false;
    }

    return strCleanner('id', json_encode($id));
}

////////////////////////////////////////////////////////

// echo json_encode(updateFields());
echo json_encode($_SESSION['name']);
echo json_encode($_SESSION['email']);
echo json_encode($_SESSION['pass']);