///////// functions /////////

function responseFieldEmail(){
    return document.getElementById('responseFieldEmail');
}

function responseFieldSubmit(){
    return document.getElementById('responseFieldSubmit');
}

function getInputs(){
    let inputs = {};
    document.querySelectorAll('input').forEach((e) => {
        inputs[e.id] = e.value;
    });
    return inputs;
}

function getInputsValues(){
    let inputs = {};
    document.querySelectorAll('input').forEach((e) => {
        inputs[e.id] = e.value;
    });
    return inputs;
}

function validateInputs(inputs){
    let cont = 0;

    if(inputs.name != ""){
        cont = cont + 1;
    }

    if(inputs.email != ""){
        cont = cont + 1;
    }

    if(inputs.pass != ""){
        cont = cont + 1;
    } else {
        responseFieldSubmit().innerHTML = "pleasse insert the new data in some input B E F O R E submiting data";
    }

    if(cont == 0){
        return false;
    }

    if(inputs.passc == ""){
        responseFieldSubmit().innerHTML = "All fields are obrigatory!";
        return false;
    }    
    return true;
}

async function post(endpoint, body){
    const res = await fetch(endpoint, {
        method: `POST`,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams(body).toString(),
    });
    return await res.json();
}

function queue(inputs){
    let queue = {
        "name":"",
        "email":"",
        "pass":""
    }

    if(inputs.name != ""){
        queue.name = inputs.name;
    }

    if(inputs.email != ""){
        queue.email = inputs.email;
    }

    if(inputs.pass != ""){
        queue.pass = inputs.pass;
    }    

    return queue;
}

document.getElementById("submitChanges").addEventListener('click', async () => {
    console.log("click");
    const inputs = getInputs();

    if(validateInputs(inputs)){
        const res = await post('http://localhost/Fullstack-Project---TCG-Storage-Manager/Index/src/controllers/user.php', queue(inputs))
        console.log(res);
    }
});