/////// functions ///////

function getInputs(){
    let inputs = {};
    document.querySelectorAll('input').forEach((e) => {
        inputs[e.id] = e.value;
    });
    return inputs;
}

function responseField(){
    return document.getElementById('responseField');
}

function validateInputs(inputs){
    let token = false;
    if(voidCheck(inputs)){
        if(pssConfirm(inputs)){
            token = true;
        } 
    }
    return token;
}

function pssConfirm(inputs){
    if(inputs.pass !== inputs.passc){
        responseField().innerHTML = "Passwords dont check";
        return false;
    }
    return true;
}

function voidCheck(inputs){
    if(inputs.name == "" || null || undefined){
        responseField().innerHTML = "All fields are obrigatory!";
        return false;
    }

    if(inputs.email == "" || null || undefined){
        responseField().innerHTML = "All fields are obrigatory!";
        return false;
    }

    if(inputs.pass == "" || null || undefined){
        responseField().innerHTML = "All fields are obrigatory!";
        return false;
    }

    if(inputs.passc == "" || null || undefined){
        responseField().innerHTML = "All fields are obrigatory!";
        return false;
    }

    return true;
}

async function post(endpoint, body){
    const res = await fetch(endpoint, {
        method: `POST`,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams(body).toString(),
    });
    return await res.json();
}
/////////////////////////

document.querySelector('#btn').addEventListener('click', async () => {
    console.log("click");
    const inputs = getInputs();

    if(validateInputs(inputs)){
        const body = 
        {
            'name': inputs.name,
            'pass': inputs.pass,
            'email': inputs.email
        }
        const res = await post('http://localhost/Fullstack-Project---TCG-Storage-Manager/Index/src/controllers/registrate.php', body)
        console.log(res);
    
        if(res == true){
            responseField().innerHTML = "Registrated Sucessfully!";
        } 
        if(res == false){
            responseField().innerHTML = "User already exists, try another email";
        }
    }
});