/////// functions ///////

function getInputs(){
    let inputs = {};

    document.querySelectorAll('input').forEach((e) => {
        inputs[e.id] = e.value;
    });
    
    // if(voidCheck(inputs)){
        return inputs;
    // }

    // return false;
}

function voidCheck(inputs){
    if(inputs.name == "" || null || undefined){
        window.alert("todos campos são obrigatórios");
        return false;
    }

    if(inputs.email == "" || null || undefined){
        window.alert("todos campos são obrigatórios");
        return false;
    }

    if(inputs.pass == "" || null || undefined){
        window.alert("todos campos são obrigatórios");
        return false;
    }

    if(inputs.passc == "" || null || undefined){
        window.alert("todos campos são obrigatórios");
        return false;
    }

    return true;
}

async function post(endpoint, body){
    const res = await fetch(endpoint, {
        method: `POST`,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams(body).toString(),
    });
    return await res.json();
}

/////////////////////////

document.querySelector('#btn').addEventListener('click', async () => {
    console.log('clicked');
    const inputs = getInputs();
    const body = 
        {
            'email': inputs.email,
            'pass': inputs.pass
        };
    const res = await post('http://localhost/Fullstack-Project---TCG-Storage-Manager/Index/src/controllers/login.php', body);
    console.log(res);

    if(res == true){
    } else {
        const responseField = document.getElementById("responseField");
        responseField.innerHTML = "Acess Denied";
    }
});
    
